#include <ros/ros.h>
#include <config_parser/ParseConfig.h>
#include <config_parser/AddTimestamp.h>


bool parseConfig(config_parser::ParseConfig::Request& req, config_parser::ParseConfig::Response& res)
{
  std::cout << req.path std::endl;
  return true;
}

int main(int argc, char** argv)
{
  ros::init(argc, argv, "config_parser");
  ros::NodeHandle nh;

  ros::ServiceServer service = nh.advertiseService("config_parser", parseConfig);
  ROS_INFO("Ready");
  ros::spin();

  return 0;
}

